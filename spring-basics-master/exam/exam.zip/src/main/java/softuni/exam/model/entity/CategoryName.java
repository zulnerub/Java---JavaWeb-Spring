package softuni.exam.model.entity;

public enum CategoryName {
    FOOD, DRINK, HOUSEHOLD, OTHER
}
